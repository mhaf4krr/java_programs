import java.awt.*;
import javax.swing.*;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


 
 
public class Calculator extends JPanel implements ActionListener {
  private JFrame frame;
  private JTextField display = new JTextField("0");
  private double result = 0;
  private String operator = "=";
  private boolean calculating = true;
 
  public Calculator() {
    setLayout(new BorderLayout());
    
    frame = new JFrame();
    frame.setTitle("CSE-16-SL-128");
    frame.setSize(200, 300);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setResizable(false);
    /* set font for TextField to increase its height */
    Font font = new Font("Times New Roman", Font.BOLD,20);
    display.setFont(font);
    display.setEditable(false);
    
    frame.getContentPane().add(BorderLayout.NORTH,display);
 
    JPanel panel = new JPanel();
    panel.setLayout(new GridLayout(4, 4));
 
    /* Adds all the buttons to the Grid */

    String buttonLabels = "789/456*123-0.=+";
    for (int i = 0; i < buttonLabels.length(); i++) {
      JButton b = new JButton(buttonLabels.substring(i, i + 1));
      
      /* Setting up color Scheme */

      if(b.getActionCommand().charAt(0) == '/' || b.getActionCommand().charAt(0) =='*' || b.getActionCommand().charAt(0) =='+' || b.getActionCommand().charAt(0) =='-' || b.getActionCommand().charAt(0) == '/' || b.getActionCommand().charAt(0) == '='){
        if(b.getActionCommand().charAt(0) == '='){
          /* Color Scheme for equals to */
          b.setBackground(Color.green);
          b.setForeground(Color.white);
        }

        else {
          /* Color Scheme for Operators */
          b.setBackground(Color.gray);
          b.setForeground(Color.white);
        }

      }
      else {
        /* Color Scheme for Digits */
        b.setBackground(Color.black);
        b.setForeground(Color.white);
      
      }

      b.setFont(new Font("Times New Roman",Font.BOLD,18));
      panel.add(b);
      b.addActionListener(this);
    }
    
    frame.getContentPane().add(BorderLayout.CENTER,panel);
    frame.setVisible(true);
  }
 
  public void actionPerformed(ActionEvent evt) {

    /* getActionCommand returns button text just like JS .innerText */
    String cmd = evt.getActionCommand();
    
    if ('0' <= cmd.charAt(0) && cmd.charAt(0) <= '9' || cmd.equals(".")) {
      if (calculating)
      /* Next Operand should be given a clear screen after an operator has been used*/
        display.setText(cmd);
      else
      /* Add digits to the current operand  */
        display.setText(display.getText() + cmd);
      calculating = false;
    } 
    
    /*  Handle operators */
    else {
      
        double x = Double.parseDouble(display.getText());
        calculate(x);
        operator = cmd;
        calculating = true;
      
    }
  }
 
  private void calculate(double n) {
    System.out.println("Result: "+result+" Operator: "+operator+ " n:"+n);
    if (operator.equals("+"))
      result += n;
    else if (operator.equals("-"))
      result -= n;
    else if (operator.equals("*"))
      result *= n;
    else if (operator.equals("/"))
      result =  (int)(result/n);
    else if (operator.equals("="))
      result = n;
    display.setText("" + result);
  }
 
  public static void main(String[] args) {
    new Calculator();
  }
}